from _collections_abc import *
from _collections_abc import __all__  # noqa: F401
from _collections_abc import _CallableGenericAlias  # noqa: F401
